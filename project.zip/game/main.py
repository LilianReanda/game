import pygame
from pygame.locals import *
import random

Name = "Adventures of Jumpy the Block"
Width = 700
Height = 800
screen = pygame.display.set_mode((Width, Height))
pygame.display.set_caption(Name)
pygame.font.init()
myfont = pygame.font.SysFont('Comic Sans MS', 30)

playerR = 255
playerG = 255
playerB = 255
playerX = Width / 2
playerY = 0
playerSize = 30
playerAccel = 0

R = 60
G = 200
B = 100

gravity = 4
timeRate = 20
numforms = 4
platThick = 20
platwide = 80
typemin = 2
typemax= 7
skew = 20

platforms = [[100,100,20,50,1]]
counter = 0
score = 0
distance_left = 0
loss = False

playing = True
starting = True

class Gamefunctions:
    def maxi(a,b):
        return [a,b][a < b]

    def mini(a,b):
        return [a,b][a > b]

    def intersects(one, two):
        return ((two[0] <= one[0] <= two[0] + two[2]) or (two[0] <= one[0] + one[2] <= two[0] +two[2])) and ((two[1] <= one[1] <= two[1] + two[3]) or (two[1] <= one[1] + one[3] <= two[1] + two[3]))

class lossTime(Gamefunctions):
    def __init__(self,time):
        self.time = time

while playing:
    if starting:
        screen.fill((0, 0, 0))
        textsurface = myfont.render('Press space to start', False, (255, 255, 255))
        screen.blit(textsurface, (Width // 2, Height // 2))
        pygame.display.flip()
    while starting:
        pressed_keys = pygame.key.get_pressed()
        if pressed_keys[K_SPACE]:
            starting = 0
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                playing = 0
                starting = 0
    screen.fill((R, G, B))
    pressed_keys = pygame.key.get_pressed()
    #begin body of code
    #player things
    inter = 0
    i = -1
    id = 0
    recta = (playerX,playerY,playerSize,playerSize)
    for platform in platforms:
        i += 1
        rectb = (platform[0],platform[1],platform[2],platform[3])
        if Gamefunctions.intersects(recta,rectb):
            inter = platform[4]
            id = i
            break
    if inter:
        playerAccel = Gamefunctions.mini(gravity - 2,playerAccel)
    if inter - 1 % 4 == 0:
        playerAccel = -30
    if inter - 1 % 5 == 0:
        playerAccel *= 2
        playerAccel = Gamefunctions.maxi(playerAccel,-50)
    if inter - 1 % 6 == 0:
        del platforms[id]
    if playerX < 0:
        playerX = Width
    if playerX > Width + 1:
        playerX = 1
    if pressed_keys[K_SPACE] and inter:
        playerAccel = -18
    if pressed_keys[K_LEFT]:
        playerX -= 1
    if pressed_keys[K_RIGHT]:
        playerX += 1
    #generate new zones
    if distance_left == 0:
        distance_left = random.randint(1000,3000)
        R = random.randint(10,255)
        G = random.randint(10,255)
        B = random.randint(10,255)
        gravity = random.randint(random.randint(2,3),random.randint(3,6))
        timeRate = random.randint(random.randint(8,15),random.randint(15,30))
        numforms = random.randint(4,8)
        platThick = random.randint(10,40)
        platwide = random.randint(30, 90)
        typemin = random.randint(0,10)
        typemax = random.randint(typemin + 1, typemin+ 8)
        skew = random.randint(-30,30)
        del platforms[0]
    #generate new platforms
    if len(platforms) < numforms and random.randint(0,6) == 0:
        newP = [Gamefunctions.maxi(Gamefunctions.mini(random.randint(0,Width) + skew,Width),0),0,platwide,platThick,random.randint(typemin,typemax)]
        newP[2] += newP[4] * 3
        newP[3] += (newP[4] + 2) * 2
        platforms.append(newP)
    #drop , player
    i = -1
    counter += 1
    if counter >= timeRate:
        score += 1
        distance_left -= 1
        counter = 0
        playerAccel += Gamefunctions.mini(1,gravity / 2 -1)
        playerY += playerAccel
        for platform in platforms:
            i += 1
            #move
            platforms[i][1] += (gravity - 2 + (7 % (platform[4] + 1)))
            #delete if needed
            if platforms[i][1] > Height + 1:
                del platforms[i]
                i -= 1
    #detect game end
    if playerY > Height + 1:
        playing = False
        loss = True
    #draw things
    for platform in platforms:
        recta = Rect(platform[0],platform[1],platform[2],platform[3])
        pygame.draw.rect(screen,(Gamefunctions.maxi(R - platform[4] % 2 * 40,0),Gamefunctions.maxi(G - (platform[4] % 3 + 1) * 12,0),Gamefunctions.maxi(B - platform[4] % 4 * 8,0)),recta)
    recta = Rect(playerX,playerY,playerSize,playerSize)
    pygame.draw.rect(screen, (playerR,playerG,playerB),recta)
    textsurface = myfont.render(str(score), False, (255, 255, 255))
    screen.blit(textsurface, (Width - 120, 40))
    pygame.display.flip()
    #end of loop area
    pygame.display.flip()
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            playing = 0
    if loss:
        remain = lossTime(1000000)
        # draw loss screen
        textsurface = myfont.render('You Lose', False, (255, 255, 255))
        screen.blit(textsurface,(Width // 2,Height // 2))
        pygame.display.flip()
        while remain.time > 0:
            remain.time -= 1
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    remain.time = 0

